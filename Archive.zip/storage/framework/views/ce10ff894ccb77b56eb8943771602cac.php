<link rel="icon" type="image/x-icon" href="<?php echo e(url('assets/images/Logo.ico')); ?>" />
<link href="<?php echo e(url('assets/css/loader.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(url('assets/js/loader.js')); ?>"></script>
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
<link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(url('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(url('assets/css/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(url('assets/css/dash_1.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(url('assets/js/jquery-3.1.1.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css" />

<?php /**PATH /Users/hanciephago/Desktop/Laravel Projects/hancie_phago/resources/views/layouts/adminheader.blade.php ENDPATH**/ ?>