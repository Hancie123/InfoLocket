<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bio;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class AccountSettingController extends Controller
{
    public function accountsetting(){
        $biodata=DB::table('users')->join('bios','bios.user_id','=','users.id')
        ->select('users.name','bios.bio','bios.profession','bios.dob','users.id')
        ->get();

        foreach ($biodata as $entry) {
            $user = User::find($entry->id); // Use $entry->id to find the user
            $entry->media = $user->getMedia('profile_image');
        }

        $count=$biodata->count();
        return view('admin/accountsetting',compact('biodata','count'));
    }
}
